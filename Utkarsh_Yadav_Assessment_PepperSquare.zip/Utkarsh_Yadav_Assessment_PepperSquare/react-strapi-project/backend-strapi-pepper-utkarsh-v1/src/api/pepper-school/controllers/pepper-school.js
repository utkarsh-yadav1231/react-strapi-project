'use strict';

/**
 * pepper-school controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::pepper-school.pepper-school');

